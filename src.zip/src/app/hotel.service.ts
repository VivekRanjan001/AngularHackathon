import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Hotel } from './hotel';

@Injectable({
providedIn: 'root'
})
export class HotelService {
private apiUrl = 'http://localhost:3000/';

constructor(private http: HttpClient) { }

getHotels(): Observable<Hotel[]> {
return this.http.get<Hotel[]>(this.apiUrl);
}
}
