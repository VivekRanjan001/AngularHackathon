import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { MenuItem } from './menu-item';

@Injectable({
providedIn: 'root'
})
export class MenuItemService {
private apiUrl = 'http://localhost:5000/api/hotels';

constructor(private http: HttpClient) { }

getMenuItemsByHotelId(hotelId: string): Observable<MenuItem[]> {
const url = `${this.apiUrl}/${hotelId}/menu`;
return this.http.get<MenuItem[]>(url);
}
}
