import { Component, OnInit } from '@angular/core';
import { CartService } from '..//cart.service';
import { MenuItem } from '../menu-item';

@Component({
selector: 'app-cart',
templateUrl: './cart.component.html',
styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {
  cartItems: MenuItem[] = [];

constructor(private cartService: CartService) { }

ngOnInit() {
this.cartItems = this.cartService.getCartItems();
}

removeFromCart(item: MenuItem) {
this.cartService.removeFromCart(item);
}

getTotal() {
return this.cartService.getTotal();
}
}
