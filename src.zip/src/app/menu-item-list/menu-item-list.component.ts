import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { MenuItemService } from '../menu-item.service';
import { MenuItem } from '../menu-item';
import { CartService } from '../cart.service';

@Component({
selector: 'app-menu-item-list',
templateUrl: './menu-item-list.component.html',
styleUrls: ['./menu-item-list.component.css']
})
export class MenuItemListComponent implements OnInit {
  menuItems: MenuItem[] = [];

constructor(
private route: ActivatedRoute,
private menuItemService: MenuItemService,
private cartService: CartService
) { }

ngOnInit() {
const hotelId = this.route.snapshot.paramMap.get('id');
if (hotelId) {
this.menuItemService.getMenuItemsByHotelId(hotelId)
.subscribe(menuItems => this.menuItems = menuItems);
}
}

addToCart(menuItem: MenuItem) {
this.cartService.addToCart(menuItem);
}
}
